package com.findsportmates.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.findsportmates.dao.UserDAO;
import com.findsportmates.model.User;

@Service
public class UserServiceImpl implements UserService {
	
	private UserDAO userDAO;
	
	public void setuserDAO(UserDAO userDAO) {
		this.userDAO = userDAO;
	}
	
	@Transactional
	public void addUser(User u) {
		this.userDAO.addUser(u);
	}
	
	@Transactional
	public void updateUser(User u) {
		this.userDAO.updateUser(u);
	}
	
	@Transactional
	public List<User> listUsers() {
		return this.userDAO.listUsers();
	}
	
	@Transactional
	public User getUserById(int id) {
		return this.userDAO.getUserById(id);
	}
	
	@Transactional
	public void removeUser(int id) {
		this.userDAO.removeUser(id);
	}
	
	@Transactional
	public User getUserByName(String username ) {
		
		return this.userDAO.getUserByName(username);
	}
	
	@Transactional
	public boolean isUserValid(String username, String password) {
		print();
		User myUser = getUserByName(username);
		String name= myUser.getUsername();
		String pass= myUser.getPassword();
		if (username.equals(name) && password.equals(pass))
			return true;
		return false;
	}

	private void print() {
		System.out.println("checking the user......");
	}

}
