package com.findsportmates.controller;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.findsportmates.model.User;
import com.findsportmates.service.UserService;

@Controller
@SessionAttributes("userid") // only use when generic parameter bc it takes memory
public class UserController {
	
	private UserService userService;
	
	@Autowired(required = true)
	@Qualifier(value = "userService")
	public void setUserService(UserService us) {
		this.userService = us;
	}
	
	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String showRegisterPage(ModelMap model){
		model.addAttribute("user", new User()); 
		return "register";
	}
	
	
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String addUser(ModelMap model, User user) {
		printUser(user);
		this.userService.addUser(user);
		return "login";
	}

	private void printUser(User user) {
		System.out.println(user);
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String showLoginPage(){
		return "login";
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String handleLoginRequest(@RequestParam String username, @RequestParam String password, ModelMap model){
		boolean validUser= userService.isUserValid(username, password);
		if(!validUser){
			putInMap(model);
			return "login";
		}
		
		User user= userService.getUserByName(username);
		int id= user.getId();
		addAttribute(model, id);
		return "redirect:/event";
	}

	private void addAttribute(ModelMap model, int id) {
		model.addAttribute("userid", Integer.toString(id));
	}

	private void putInMap(ModelMap model) {
		model.put("errorMsg", "Invalid user");
	}

	@RequestMapping(value = "/search-user", method = RequestMethod.GET)
	public String showSearchUserPage(ModelMap model){
		//model.addAttribute("user", new User());
		return "searchuser";
	}
	
	@RequestMapping(value = "/search-user", method = RequestMethod.POST)
	public String searchtEvent(ModelMap model,@RequestParam("username") String username) {
		print(username);
		User result = this.userService.getUserByName(username);
		addAttribute(model, result);
		return "searchuser_result";

	}

	private void print(String username) {
		System.out.println("test:  "+ username);
	}

	private void addAttribute(ModelMap model, User result) {
		model.addAttribute("user", result);
	}
}
