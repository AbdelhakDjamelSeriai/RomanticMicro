package com.findsportmates.dao;

import org.springframework.stereotype.Repository;

@Repository
public class ParticipantDAOImpl implements ParticipantDAO{

	public void addParticipant(int userid) {
		
		
	}

	public void updateParticipant(int userid) {
		
		
	}

	public String getParticipantById(int id) {
		
		return null;
	}

	public void removeParticipant(int id) {
		
		
	}

}

