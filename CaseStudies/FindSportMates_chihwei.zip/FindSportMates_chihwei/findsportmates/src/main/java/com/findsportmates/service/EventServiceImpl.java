package com.findsportmates.service;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.findsportmates.dao.EventDAO;
import com.findsportmates.model.Event;
import com.findsportmates.model.User;
//import com.findsportmates.model.EventFactory;
@Service
public class EventServiceImpl implements EventService {
	
	private EventDAO eventDAO;
	
	public void setEventDAO(EventDAO EventDAO) {
		this.eventDAO = EventDAO;
	}
	
	@Transactional
	public void addEvent(Event e) {
		this.eventDAO.addEvent(e);
	}
	
	@Transactional
	public void updateEvent(Event e) {
		this.eventDAO.updateEvent(e);
	}
	
	@Transactional
	public List<Event> listEvents() {
		return this.eventDAO.listEvents();
	}
	
	@Transactional
	public Event getEventById(int id) {
		return this.eventDAO.getEventById(id);
	}
	
	@Transactional
	public void removeEvent(int id) {
		this.eventDAO.removeEvent(id);
	}
	
	@Transactional
	public List<Event> listUserEvents(int id) {
		return this.eventDAO.listUserEvents(id);
	}
	
	@Transactional
	public List<Event> searchEvent(String type, String date, String num_L, String num_U) {
	    List<Event> list= createList();
	    System.out.println(type);
		if (type.equals("unrestricted")){
			list=this.eventDAO.SearchDateTimeRange(date,num_L,num_U);
		}else if(num_L.equals("unrestricted") & num_U.equals("unrestricted")){
			list=this.eventDAO.SearchType(type);
		}else{
		    list=this.eventDAO.SearchTypeAndDateTimeRange(type,date,num_L,num_U);
		}

		return list;
	}

	private List<Event> createList() { 
		return new LinkedList<Event>();
	}
	
	@Transactional
	public void addParticipant(int id, User u) {
		
		Event e = getEventById(id);
		Set<User> users= e.getParticipants();
		Set<User> p = newMethod(users);
		for(User user: p){
			print(user);
		}
		//Set<User> p = eventDAO.getParticipants(e.getEventId());
		add(u, p);
		e.setParticipants(p);
		updateEvent(e);
	}

	private Set<User> newMethod(Set<User> users) {
		Set<User> p = new HashSet<User>();
		p.addAll(users);
		return p;
	}

	private void print(User u) {
		System.out.println("Participants List::" + u);
	}

	private void add(User u, Set<User> p) {
		p.add(u);
	}


}
