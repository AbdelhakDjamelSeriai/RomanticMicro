package com.findsportmates.model;


public class Basketball extends Event {
	
	public Basketball(int eventId, int hostId, String eventTime, String eventPlace) {
		setEventType("Basketball");
		setEventId(eventId);
		setHostId(hostId);
		setEventTime(eventTime);
		setEventPlace(eventPlace);
	}
	
	public void changeBasketballEventTime(String eventTime){
		setEventTime(eventTime);
	}

}
