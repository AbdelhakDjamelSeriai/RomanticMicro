package com.gt.common.constants;

/**
 * DB Status
 *
 * @author GT
 */
public enum Status {
    NONE, READ, CREATE, MODIFY, DELETE, MODIFY_CATEGORY_NAME;

    @Override
    public String toString() {
        return super.toString();

    }
}
