package com.ca.db.service;

import com.gt.db.BaseDAO;

public class PersonServiceImpl extends BaseDAO {

    public PersonServiceImpl() throws Exception {
        super();
    }

    public void deletePerson(){
    	
    }
}
