package com.ca.db.service;

import com.gt.db.BaseDAO;

public class DepartmentServiceImpl extends BaseDAO {

    public DepartmentServiceImpl() throws Exception {
        super();
    }

}
