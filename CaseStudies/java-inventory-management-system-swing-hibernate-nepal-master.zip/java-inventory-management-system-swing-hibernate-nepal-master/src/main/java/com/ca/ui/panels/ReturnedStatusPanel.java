package com.ca.ui.panels;

import javax.swing.JPanel;

public class ReturnedStatusPanel extends JPanel {
	
	public  void returnedStatusPanelMethod(){
		
	}

}
