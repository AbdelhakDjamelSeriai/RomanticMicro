## Inventory Management System (in Nepal's context)

##### Note:I wrote this as a test project to practice DBMS/Java/Hibernate during my early days of programming (2011-2012). 

#### This uses following libraries/frameworks
- Swing 
- JGoodies 
- Hibernate 
- H2 Database 
- Jasper

#### How to run the application
- Clone/Download the project and import into your IDE
- Run com.ca.ui.Main as Java Application

###For any queries :
- Email : gtiwari333@gmail.com
- Blog : http://ganeshtiwaridotcomdotnp.blogspot.com/ 


##### CopyLeft:
- Please feel free to use/modify the code! 
- But make sure to give me credit by keeping the class header or add reference to this GitHub repository.
  